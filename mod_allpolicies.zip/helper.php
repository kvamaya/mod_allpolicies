<?php

class ModHelloWorldHelper
{

    public static function getDataFromLisk($params)
    {
	return 'Hello, World!';
    }
}